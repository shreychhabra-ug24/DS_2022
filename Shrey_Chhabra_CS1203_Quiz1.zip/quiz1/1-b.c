#include <stdio.h>

void advancedFizzBuzz(int *a, int m, int *b, int nb, int *f, int nf){
    int f[] = {3,5};
    int b[] = {11,13};
    nf = 2;
    nb = 2;
    printf("enter the length of the input array: ");
    scanf("%d",m);
    int a[] = {};
    m = sizeof(a);

    printf("Enter the array inputs: ");
    for(int i=0; i<m; i++){
        scanf("%d", &a[i]);
    }
    

}